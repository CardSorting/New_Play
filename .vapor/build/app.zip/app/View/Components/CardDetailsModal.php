<?php

namespace App\View\Components;

use Illuminate\View\Component;

class CardDetailsModal extends Component
{
    public function render()
    {
        return view('components.card-details-modal');
    }
}
